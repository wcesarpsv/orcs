#pragma once
#include <WebServer.h>
#include <Preferences.h>
#include <time.h>
#include <esp_system.h>

static const char *SETUP_SSID = "Carmanah-Setup";
static const char *SETUP_PASSWORD = "carmanah123";
WebServer setupServer(80);
String savedSsid, savedPassword, savedApiUrl, savedCa;
String setupToken, wifiNotice = "Starting";
bool portalReady = false, wifiConnecting = false, wifiApplyPending = false;
bool wasWifiConnected = false;
uint32_t wifiApplyAt = 0, wifiAttemptAt = 0, wifiRetryAt = 0;

bool portalClientAllowed() {
  // Only requests addressed to the setup interface can change settings.
  return setupServer.client().localIP() == WiFi.softAPIP();
}

bool portalRequestAllowed(bool write = false) {
  if (!portalClientAllowed()) {
    setupServer.send(403, "text/plain", "Connect to Carmanah-Setup first."); return false;
  }
  setupServer.sendHeader("Cache-Control", "no-store");
  if (write && setupServer.arg("token") != setupToken) {
    setupServer.send(403, "text/plain", "Session expired. Reload setup page."); return false;
  }
  return true;
}

String wifiSetupPage() {
  String page = R"HTML(<!doctype html><html lang="en"><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Carmanah Wi-Fi setup</title><style>
body{font:16px system-ui;background:#101a24;color:#edf4fa;margin:0;padding:22px}
main{max-width:520px;margin:auto}h1{font-size:26px}label{display:block;margin:18px 0 7px}
input,select,textarea,button{box-sizing:border-box;width:100%;padding:12px;border-radius:9px;border:1px solid #546578;font:inherit}
input,select,textarea{background:#172735;color:white}button{background:#62d3c3;color:#10232b;font-weight:700;margin-top:16px;cursor:pointer}
small,p{line-height:1.5;color:#bed0df}#status{background:#203443;padding:14px;border-radius:10px;white-space:pre-line}
summary{margin-top:25px;cursor:pointer}textarea{font:12px monospace}a{color:#62d3c3}
</style><main><h1>Carmanah Wi-Fi setup</h1>
<p>Connect to a 2.4 GHz Wi-Fi network or phone hotspot. Settings survive power off.</p>
<div id="status">Loading status...</div>
<form id="settings"><input type="hidden" name="token" value="__TOKEN__">
<label for="rdl">Site RDL</label><input id="rdl" name="rdl" inputmode="numeric" pattern="[0-9]{1,8}" maxlength="8" required placeholder="Example: 44483">
<label for="expected">Carmanah signs expected at this RDL</label><select id="expected" name="expected"><option value="1">1</option><option value="2">2</option><option value="3">3</option><option value="4">4</option><option value="5">5</option><option value="6">6</option><option value="7">7</option><option value="8">8</option></select>
<small>Signal strength suggests nearby signs. Confirm the serial numbers before linking them to this RDL.</small>
<button type="button" id="scan">Find Wi-Fi networks</button>
<label for="networks">Available networks</label><select id="networks"><option value="">Choose or enter below</option></select>
<label for="ssid">Network name (SSID)</label><input id="ssid" name="ssid" maxlength="32" required autocomplete="off">
<label for="password">Wi-Fi password</label><input id="password" name="password" type="password" maxlength="64" autocomplete="new-password">
<small>Leave empty to keep the saved password for the same network. For an open network, check below.</small>
<label><input style="width:auto" type="checkbox" name="open" value="1"> This network has no password</label>
<details><summary>Vercel jackpot source</summary>
<p>Jackpots are downloaded from ORCS Reports on Vercel over HTTPS. Public CA trust roots are included.</p>
<label for="api">Vercel JSON URL</label><input id="api" name="api" type="url" readonly placeholder="Vercel JSON endpoint" maxlength="512">
<small>Verified HTTPS trust roots are built into firmware v10.6. No certificate configuration is needed.</small>
</details><button type="submit">Save and connect</button></form>
<p id="message" role="status"></p><p>After confirming Connected, disconnect from Carmanah-Setup so jackpot updates can resume. If disconnected during setup, reconnect to Carmanah-Setup and open http://192.168.4.1.</p>
<section><h2>Carmanah serial numbers</h2>
<p>Tests the observed IQ command (up to 3 attempts) and listens for validated IA replies during radio windows. Suggestions require 60 seconds and 3 messages per SN. Check the sign labels before confirming.</p>
<pre id="inventory" style="white-space:pre-wrap;overflow-wrap:anywhere">Loading inventory...</pre>
<button type="button" id="listen-sn">Listen for SNs (60s, pauses AUTO)</button>
<small>Wi-Fi setup will pause during listening. Reconnect to Carmanah-Setup after 60 seconds.</small>
<button type="button" id="confirm-sn">Confirm suggested SNs for this RDL</button>
<a href="/inventory.json" download="carmanah_inventory.json">Download inventory JSON</a>
<p id="inventory-message"></p>
<small>Prototype: stored on the C6 only. No database upload is configured yet.</small></section>
<script>
const $=id=>document.getElementById(id);let initialized=false,scanning=false;
async function status(){try{const r=await fetch('/status',{cache:'no-store'});if(!r.ok)throw Error('Setup unavailable');const s=await r.json();
$('status').textContent=s.message+'\n'+(s.connected?'Connected to '+s.ssid+'\nNetwork IP: '+s.ip:'Wi-Fi offline')+'\nJackpot API: '+s.api;
if(!initialized){$('ssid').value=s.saved_ssid;$('api').value=s.api_url;$('rdl').value=s.rdl;$('expected').value=String(s.expected_signs);initialized=true;}}
catch(e){$('status').textContent='Reconnect to Carmanah-Setup, then reload this page.';}}
$('networks').onchange=()=>{if($('networks').value)$('ssid').value=$('networks').value;};
async function scan(){if(scanning)return;scanning=true;$('scan').disabled=true;$('scan').textContent='Searching...';
try{for(let i=0;i<30;i++){const r=await fetch('/scan',{cache:'no-store'});if(!r.ok)throw Error('Scan failed');const s=await r.json();
if(!s.running){$('networks').replaceChildren(new Option('Choose or enter below',''));for(const n of s.networks)$('networks').add(new Option(n.ssid+' ('+n.rssi+' dBm)'+(n.open?' - open':''),n.ssid));return;}
await new Promise(resolve=>setTimeout(resolve,600));}throw Error('Scan timed out; enter SSID manually.');}
catch(e){$('message').textContent=e.message;}finally{scanning=false;$('scan').disabled=false;$('scan').textContent='Find Wi-Fi networks';}}
$('scan').onclick=scan;
$('settings').onsubmit=async e=>{e.preventDefault();const b=e.submitter;b.disabled=true;try{const data=new URLSearchParams(new FormData(e.target));
const r=await fetch('/save',{method:'POST',body:data});$('message').textContent=await r.text();if(r.ok){$('password').value='';}}
catch(e){$('message').textContent='Connection changed. Reconnect to Carmanah-Setup and reload.';}finally{b.disabled=false;}};
let inventorySnapshot=null;
async function loadInventory(){try{const r=await fetch('/inventory.json',{cache:'no-store'});if(!r.ok)throw Error('Inventory unavailable');
const d=await r.json();inventorySnapshot=d;
const lines=['RDL: '+(d.rdl||'Not set')+' | Expected: '+d.expected_signs,
'IQ attempts / radio success / failed: '+d.iq_attempts_this_window+' / '+d.iq_radio_success_this_window+' / '+d.iq_radio_failed_this_window,
'Validated IA messages this boot: '+d.validated_ia_messages];
for(const x of d.signs){lines.push(x.sn+' | '+(x.median_rssi_dbm===null?'RSSI pending':x.median_rssi_dbm+' dBm')+' | '+(x.confirmed?'CONFIRMED':x.suggested?'SUGGESTED':'UNASSIGNED')+' | '+x.status+' | messages: '+x.received_count);}
if(!d.signs.length)lines.push('No SN captured yet.');
if(d.ambiguous_boundary)lines.push('Close signal levels: check labels before confirming.');
if(d.table_full_drops)lines.push('Inventory capacity reached; contact support before adding more signs.');
$('inventory').textContent=lines.join('\n');}
catch(e){$('inventory-message').textContent=e.message;}}
async function inventoryPost(path,data){data.token='__TOKEN__';const r=await fetch(path,{method:'POST',body:new URLSearchParams(data)});$('inventory-message').textContent=await r.text();if(r.ok)loadInventory();}
$('listen-sn').onclick=()=>inventoryPost('/inventory/listen',{}).catch(e=>{$('inventory-message').textContent='Reconnect after listening.';});
$('confirm-sn').onclick=()=>{const d=inventorySnapshot;if(!d||!d.ranking_ready){$('inventory-message').textContent='Need 60 seconds and enough validated SN samples first.';return;}
const sns=d.signs.filter(x=>x.suggested).map(x=>x.sn).sort().join(',');
if(confirm('Confirm these SNs belong to RDL '+d.rdl+'? '+sns))inventoryPost('/inventory/confirm',{rdl:d.rdl,sns}).catch(e=>{$('inventory-message').textContent=e.message;});};
status();loadInventory();setInterval(status,2500);setInterval(loadInventory,5000);
</script></main></html>)HTML";
  page.replace("__TOKEN__", setupToken);
  return page;
}

void beginSavedWifi() {
  if (savedSsid.isEmpty()) { wifiNotice = "Choose your Wi-Fi network"; return; }
  WiFi.disconnect(false, false);
  WiFi.begin(savedSsid.c_str(), savedPassword.c_str());
  wifiAttemptAt = millis(); wifiConnecting = true;
  wifiNotice = "Connecting to saved network...";
}

void initWifiSetup() {
  Preferences prefs;
  if (prefs.begin("carmanah-net", true)) {
    String raw = prefs.getString("config", ""); prefs.end();
    JsonDocument config;
    if (!deserializeJson(config, raw)) {
      savedRdl = config["rdl"] | "";
      expectedSigns = config["expected_signs"] | 1;
      if(expectedSigns<1||expectedSigns>8)expectedSigns=1;
      savedSsid = config["ssid"] | "";
      savedPassword = config["password"] | "";
      savedApiUrl = config["api"] | "";
      savedCa = config["ca"] | "";
    }
  }
  inventoryLoad();
  savedApiUrl = API_URL; // This firmware reads the Vercel jackpot API.
  // Use the firmware public CA roots after migration; ignore old Streamlit-only saved CA.
  savedCa = VERCEL_ROOT_CA;
  WiFi.persistent(false); // credentials are saved once in our Preferences record
  WiFi.mode(WIFI_AP_STA);
  WiFi.setAutoReconnect(true);
  WiFi.setSleep(false);
  WiFi.softAPConfig(IPAddress(192,168,4,1), IPAddress(192,168,4,1), IPAddress(255,255,255,0));
  portalReady = WiFi.softAP(SETUP_SSID, SETUP_PASSWORD);
  Serial.printf("Boot AP started=%d IP=%s\n",portalReady,WiFi.softAPIP().toString().c_str());
  char token[33];
  snprintf(token, sizeof(token), "%08lx%08lx%08lx%08lx",
    (unsigned long)esp_random(), (unsigned long)esp_random(),
    (unsigned long)esp_random(), (unsigned long)esp_random());
  setupToken = token;
  setupServer.on("/", HTTP_GET, [](){
    if (portalRequestAllowed()) setupServer.send(200, "text/html; charset=utf-8", wifiSetupPage());
  });
  setupServer.on("/status", HTTP_GET, [](){
    if (!portalRequestAllowed()) return;
    JsonDocument doc;
    doc["rdl"]=savedRdl;doc["expected_signs"]=expectedSigns;
    doc["connected"] = WiFi.status() == WL_CONNECTED;
    doc["ssid"] = WiFi.SSID(); doc["saved_ssid"] = savedSsid;
    doc["ip"] = WiFi.localIP().toString(); doc["message"] = wifiNotice;
    doc["api_url"] = savedApiUrl;
    doc["api"] = savedApiUrl.isEmpty() ? "URL required" :
      savedCa.isEmpty() ? "CA certificate required" :
      time(nullptr) < 1700000000 ? "Waiting for clock sync" :
      apiValid ? "Data received" : "Waiting for valid server data";
    String body; serializeJson(doc, body); setupServer.send(200, "application/json", body);
  });
  setupServer.on("/scan", HTTP_GET, [](){
    if (!portalRequestAllowed()) return;
    JsonDocument doc; int n = WiFi.scanComplete();
    if (n == WIFI_SCAN_FAILED) { WiFi.scanNetworks(true); doc["running"] = true; }
    else if (n == WIFI_SCAN_RUNNING) doc["running"] = true;
    else {
      doc["running"] = false;
      JsonArray networks = doc["networks"].to<JsonArray>();
      for (int i = 0; i < n && i < 25; ++i) {
        if (WiFi.SSID(i).isEmpty()) continue;
        JsonObject item = networks.add<JsonObject>();
        item["ssid"] = WiFi.SSID(i); item["rssi"] = WiFi.RSSI(i);
        item["open"] = WiFi.encryptionType(i) == WIFI_AUTH_OPEN;
      }
      WiFi.scanDelete();
    }
    String body; serializeJson(doc, body); setupServer.send(200, "application/json", body);
  });
  setupServer.on("/save", HTTP_POST, [](){
    if (!portalRequestAllowed(true)) return;
    String ssid = setupServer.arg("ssid"), pass = setupServer.arg("password");
    String url = setupServer.arg("api");
    url.trim();
    String rdl=setupServer.arg("rdl"),qty=setupServer.arg("expected");rdl.trim();
    bool rdlOk=rdl.length()>0&&rdl.length()<=8;
    for(size_t i=0;i<rdl.length();++i)if(rdl[i]<'0'||rdl[i]>'9')rdlOk=false;
    if(!rdlOk||qty.length()!=1||qty[0]<'1'||qty[0]>'8'){
      setupServer.send(400,"text/plain","Enter RDL (1-8 digits) and expected signs (1-8).");return;
    }
    if (ssid.isEmpty() || ssid.length() > 32) {
      setupServer.send(400,"text/plain","Enter a network name of 1 to 32 bytes."); return;
    }
    if (setupServer.arg("open") == "1") pass = "";
    else if (pass.isEmpty() && ssid == savedSsid) pass = savedPassword;
    else if (pass.isEmpty()) {
      setupServer.send(400,"text/plain","Enter the password, or mark the network as open."); return;
    }
    bool hexKey = pass.length() == 64;
    if (hexKey) for (size_t i=0; i<pass.length(); ++i) if (!isxdigit((unsigned char)pass[i])) hexKey=false;
    if (!pass.isEmpty() && (pass.length() < 8 || (pass.length() > 63 && !hexKey))) {
      setupServer.send(400,"text/plain","Password must have 8-63 characters or a 64-digit hex key."); return;
    }
    if (url != API_URL) { setupServer.send(400,"text/plain","Use the Vercel URL supplied by this firmware."); return; }
    if ((!url.isEmpty() && (!url.startsWith("https://") || url.length() < 9 || url.indexOf(' ') >= 0 || url.indexOf('\n') >= 0 || url.indexOf('\r') >= 0)) || url.length() > 512) {
      setupServer.send(400,"text/plain","Enter the Vercel jackpot JSON URL."); return;
    }
    JsonDocument config;
    config["rdl"]=rdl;config["expected_signs"]=qty.toInt();
    config["ssid"] = ssid; config["password"] = pass; config["api"] = url;
    // The built-in CA is already in flash firmware. Do not duplicate its ~3 KB
    // in NVS: keep the Wi-Fi record small to reduce contiguous-page requirements.
    config["ca"] = ""; // Trust roots are bundled in firmware, not stored in NVS.
    String raw; serializeJson(config, raw);
    Preferences prefs;
    if (!prefs.begin("carmanah-net", false)) {
      setupServer.send(500,"text/plain","Cannot open settings storage. Nothing changed."); return;
    }
    size_t freeEntries = prefs.freeEntries();
    size_t count = prefs.putString("config", raw);
    String verified = prefs.getString("config", "");
    prefs.end();
    if (count == 0 || verified != raw) {
      Serial.printf("NVS save failed: expected=%u returned=%u free_entries=%u verified=%d\n",
        unsigned(raw.length()), unsigned(count), unsigned(freeEntries), verified == raw);
      setupServer.send(500,"text/plain",
        "Settings storage failed. Expected bytes=" + String(raw.length()) +
        ", returned=" + String(count) + ", free entries=" + String(freeEntries) +
        ". Send this message for diagnosis."); return;
    }
    Serial.printf("NVS save verified: %u bytes (credentials not logged).\n", unsigned(raw.length()));
    String previousRdl=savedRdl;uint8_t previousCount=expectedSigns;
    savedRdl=rdl;expectedSigns=uint8_t(qty.toInt());inventoryConfigChanged(previousRdl,previousCount);
    savedSsid = ssid; savedPassword = pass; savedApiUrl = url; savedCa = VERCEL_ROOT_CA;
    apiValid = false; apiTxPending = false;
    wifiApplyPending = true; wifiApplyAt = millis();
    setupServer.send(200,"text/plain","Settings saved. Connecting... Check the connection status above.");
  });
  setupServer.on("/inventory.json",HTTP_GET,[](){
    if(!portalRequestAllowed())return;JsonDocument doc;inventoryDocument(doc);
    String body;serializeJson(doc,body);setupServer.send(200,"application/json",body);
  });
  setupServer.on("/inventory/listen",HTTP_POST,[](){
    if(!portalRequestAllowed(true))return;
    if(savedRdl.isEmpty()){setupServer.send(409,"text/plain","Save the RDL and Wi-Fi settings first.");return;}
    if(inventoryScanRequested){setupServer.send(409,"text/plain","Listening already requested.");return;}
    inventoryScanRequested=true;inventoryScanAt=millis();
    setupServer.send(200,"text/plain","Listening starts now. Reconnect to Carmanah-Setup in 60 seconds.");
  });
  setupServer.on("/inventory/confirm",HTTP_POST,[](){
    if(!portalRequestAllowed(true))return;
    uint8_t order[SignInventoryCore::capacity];uint32_t epoch=uint32_t(time(nullptr));
    uint8_t n=signInventory.ranking(order,millis(),epoch>=1700000000U?epoch:0);
    if(savedRdl.isEmpty()||setupServer.arg("rdl")!=savedRdl||n<expectedSigns){
      setupServer.send(409,"text/plain","Need a saved RDL and enough observed SNs. Reload after listening.");return;
    }
    // Compare the displayed selection to the current ranking before binding.
    String selected[8];for(uint8_t i=0;i<expectedSigns;++i)selected[i]=signInventory.rows[order[i]].sn;
    for(uint8_t i=0;i<expectedSigns;++i)for(uint8_t j=i+1;j<expectedSigns;++j)if(selected[j]<selected[i]){String t=selected[i];selected[i]=selected[j];selected[j]=t;}
    String joined;for(uint8_t i=0;i<expectedSigns;++i){if(i)joined+=",";joined+=selected[i];}
    if(joined!=setupServer.arg("sns")){setupServer.send(409,"text/plain","Suggestions changed. Reload and check again.");return;}
    bool previous[SignInventoryCore::capacity];
    for(uint8_t i=0;i<signInventory.count;++i){previous[i]=signInventory.rows[i].confirmed;signInventory.rows[i].confirmed=false;}
    for(uint8_t i=0;i<expectedSigns;++i)signInventory.rows[order[i]].confirmed=true;
    inventoryDirty=true;
    if(!inventorySave()){
      for(uint8_t i=0;i<signInventory.count;++i)signInventory.rows[i].confirmed=previous[i];
      inventoryDirty=true;setupServer.send(500,"text/plain","Could not save associations. Nothing confirmed.");return;
    }
    setupServer.send(200,"text/plain","SN associations confirmed and saved on this C6. Database upload not configured.");
  });
  setupServer.onNotFound([](){
    if (portalRequestAllowed()) setupServer.send(404,"text/plain","Open http://192.168.4.1/");
  });
  setupServer.begin();
  beginSavedWifi();
  Serial.println(portalReady ? "Setup: Carmanah-Setup / http://192.168.4.1" : "Setup AP failed; reboot device.");
}

void serviceWifiSetup() {
  setupServer.handleClient();
  if (wifiApplyPending && millis() - wifiApplyAt >= 750) {
    wifiApplyPending = false; wasWifiConnected = false; beginSavedWifi();
  }
  bool connected = WiFi.status() == WL_CONNECTED;
  if (connected && !wasWifiConnected) {
    wifiConnecting = false; wifiNotice = "Connected. Settings saved.";
    configTime(0, 0, "pool.ntp.org", "time.google.com");
    apiEverPolled = false;
    Serial.print("Wi-Fi connected. IP: "); Serial.println(WiFi.localIP());
  }
  if (!connected && wasWifiConnected) {
    apiValid = false; apiTxPending = false;
    wifiNotice = "Connection lost. Reconnecting..."; wifiRetryAt = millis();
  }
  if (!connected && wifiConnecting && millis() - wifiAttemptAt >= 25000) {
    wifiConnecting = false; wifiRetryAt = millis();
    wifiNotice = "Connection failed. Check network/password; setup remains available.";
  }
  if (!connected && !wifiConnecting && !wifiApplyPending && !savedSsid.isEmpty() && millis() - wifiRetryAt >= 30000) {
    beginSavedWifi(); wifiRetryAt = millis();
  }
  wasWifiConnected = connected;
}
