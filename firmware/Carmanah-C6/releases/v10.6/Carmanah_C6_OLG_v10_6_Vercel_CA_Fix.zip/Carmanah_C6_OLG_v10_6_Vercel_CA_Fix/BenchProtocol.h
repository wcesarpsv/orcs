#pragma once
#include <stdint.h>
#include <stddef.h>
#include <stdio.h>
#include <string.h>

inline uint8_t benchChecksum(const char *p, size_t size) {
  uint32_t n = 0;
  for (size_t i = 0; i < size; ++i) n += uint8_t(p[i]);
  while (n > 255) n = (n >> 8) + (n & 255);
  return uint8_t(n);
}
inline bool benchBuildRJ(const char *id, unsigned value, char *out, size_t cap) {
  if (strcmp(id, "one") && strcmp(id, "two") && strcmp(id, "three")) return false;
  if (value > 200) return false;
  char body[32];
  int n = snprintf(body, sizeof(body), "RJ%s$%u", id, value);
  if (n < 0 || size_t(n) >= sizeof(body) || cap < size_t(n) + 7) return false;
  int written = snprintf(out, cap, ":%02x%02x%s;", n + 6,
                         unsigned(benchChecksum(body, n)), body);
  return written == n + 6;
}
