#pragma once
#include <stdint.h>

// Experimental IQ/IA relationship inferred from the user's captured log.
// Never alter addresses or try other commands automatically.
struct IdentityProbeSchedule {
  uint32_t started=0,lastAttempt=0;
  uint8_t attempts=0;
  void begin(uint32_t now){started=now;lastAttempt=0;attempts=0;}
  bool take(uint32_t now,bool slotAvailable){
    if(!slotAvailable||attempts>=3||uint32_t(now-started)<1000)return false;
    if(attempts&&uint32_t(now-lastAttempt)<20000)return false;
    ++attempts;lastAttempt=now;return true;
  }
  static const char* command(){return ":089aIQ;";}
};
