#pragma once
#include <stdint.h>

// Fixed five-minute window. Each slot sends the three values, not one field.
struct AutoRadioSchedule {
  static constexpr uint32_t durationMs = 300000;
  static constexpr uint32_t intervalMs = 5000;
  uint32_t started = 0;
  int32_t lastSlot = -1;
  void begin(uint32_t now) { started = now; lastSlot = -1; }
  uint32_t elapsed(uint32_t now) const { return uint32_t(now - started); }
  bool ended(uint32_t now) const { return elapsed(now) >= durationMs; }
  bool takeRound(uint32_t now) {
    if (ended(now)) return false;
    const int32_t slot = int32_t(elapsed(now) / intervalMs);
    if (slot <= lastSlot) return false;
    lastSlot = slot; return true;
  }
  uint32_t secondsLeft(uint32_t now) const {
    return ended(now) ? 0 : (durationMs - elapsed(now) + 999) / 1000;
  }
};
