# Carmanah ESP32-C6 v10.6 — Vercel CA Fix

Fixes the diagnosed ESP32 TLS `-9984` X509 verification failure by replacing the legacy two-root trust list with a multi-root public CA store (Amazon, ISRG, Google Trust Services, DigiCert, USERTrust and GlobalSign). TLS verification is **not disabled**. Certificate PEMs come from the local certifi/Mozilla CA store.

The API remains `https://orcs-reports.vercel.app/api/jackpots`. The Wi-Fi setup page no longer accepts/stores an override CA certificate; existing Wi-Fi credentials, RDL, inventory, and auto setting remain in NVS. Radio frame logic, channel, inventory, and 5-minute schedule are unchanged from v10.5.

**Arduino IDE**: Board ESP32C6 Dev Module, USB CDC On Boot Enabled, Core Debug Level **Error** (or None), Serial Monitor 115200. Use the original partition scheme if it fits; if not, check app partition size. **Do not enable Erase All Flash**. Changing partition scheme can affect data; back up before changing it.

Expected log: `API HTTP 200` (success logs depend on the existing sketch), then radio cycle. If `-9984` persists, send the new log; it may indicate an unlisted issuing CA, interception by a network, or certificate chain problems. This build has not been hardware-tested or compiled in this environment.
