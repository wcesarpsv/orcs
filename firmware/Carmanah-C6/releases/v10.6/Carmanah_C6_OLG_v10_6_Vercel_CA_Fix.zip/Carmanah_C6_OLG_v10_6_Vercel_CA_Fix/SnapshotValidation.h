#pragma once
#include <stdint.h>
inline bool validSnapshotTimes(uint32_t generated, uint32_t expires, uint32_t now) {
  if (uint64_t(generated) > uint64_t(now) + 60 || expires <= now || expires <= generated) return false;
  if (expires - generated > 300 || (now > generated && now - generated > 300)) return false;
  return true;
}
