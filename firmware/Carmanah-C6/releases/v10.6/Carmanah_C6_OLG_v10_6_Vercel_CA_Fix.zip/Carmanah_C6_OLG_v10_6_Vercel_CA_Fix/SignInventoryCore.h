#pragma once
#include <stdint.h>
#include <stddef.h>
#include <string.h>
#include "BenchProtocol.h"

inline int inventoryHex(char c) {
  if(c>='0'&&c<='9')return c-'0';
  if(c>='a'&&c<='f')return c-'a'+10;
  if(c>='A'&&c<='F')return c-'A'+10;
  return -1;
}
inline bool inventorySnValid(const char* sn) {
  size_t n=strlen(sn); if(n<8||n>24)return false;
  for(size_t i=0;i<n;++i) if(!((sn[i]>='A'&&sn[i]<='Z')||(sn[i]>='0'&&sn[i]<='9')))return false;
  return true;
}
inline bool inventoryParseIA(const char* msg,size_t size,char* sn,size_t cap) {
  if(size<16||size>32||msg[0]!=':'||msg[size-1]!=';'||msg[5]!='I'||msg[6]!='A')return false;
  const int a=inventoryHex(msg[1]),b=inventoryHex(msg[2]),c=inventoryHex(msg[3]),d=inventoryHex(msg[4]);
  if(a<0||b<0||c<0||d<0||size_t(a*16+b)!=size||c*16+d!=benchChecksum(msg+5,size-6))return false;
  size_t n=size-8; if(n+1>cap)return false;
  memcpy(sn,msg+7,n);sn[n]=0;return inventorySnValid(sn);
}

struct SignObservation {
  char sn[25]={};
  uint32_t firstEpoch=0,lastEpoch=0,total=0;
  uint32_t windowSamples=0;
  int8_t samples[9]={};
  uint8_t sampleCount=0,nextSample=0;
  bool confirmed=false;
  void observe(int8_t rssi,uint32_t epoch) {
    if(!firstEpoch&&epoch)firstEpoch=epoch;
    if(epoch)lastEpoch=epoch;
    ++total;++windowSamples;
    samples[nextSample]=rssi;nextSample=(nextSample+1)%9;
    if(sampleCount<9)++sampleCount;
  }
  int median() const {
    if(!sampleCount)return -127;
    int8_t sorted[9];memcpy(sorted,samples,sampleCount);
    for(int i=1;i<sampleCount;++i){int8_t v=sorted[i];int j=i-1;while(j>=0&&sorted[j]>v){sorted[j+1]=sorted[j];--j;}sorted[j+1]=v;}
    return sorted[sampleCount/2];
  }
};
struct SignInventoryCore {
  static constexpr uint8_t capacity=16;
  SignObservation rows[capacity];
  uint8_t count=0;
  uint32_t dropped=0,windowStarted=0;
  bool observing=false;
  void beginWindow(uint32_t now) {
    windowStarted=now;observing=true;
    for(uint8_t i=0;i<count;++i){rows[i].windowSamples=0;rows[i].sampleCount=0;rows[i].nextSample=0;}
  }
  int find(const char* sn) const {for(int i=0;i<count;++i)if(!strcmp(rows[i].sn,sn))return i;return -1;}
  bool add(const char* sn,int8_t rssi,uint32_t epoch) {
    if(!inventorySnValid(sn)||rssi<-126||rssi>0)return false;
    int i=find(sn);
    if(i<0){if(count==capacity){++dropped;return false;}i=count++;strcpy(rows[i].sn,sn);}
    rows[i].observe(rssi,epoch);return true;
  }
  uint8_t ranking(uint8_t* indices,uint32_t now,uint32_t epoch=0) const {
    if(!observing||uint32_t(now-windowStarted)<60000)return 0;
    uint8_t n=0;
    for(uint8_t i=0;i<count;++i)if(rows[i].windowSamples>=3&&(!epoch||(rows[i].lastEpoch&&rows[i].lastEpoch<=epoch&&epoch-rows[i].lastEpoch<10800)))indices[n++]=i;
    for(int i=1;i<n;++i){uint8_t v=indices[i];int j=i-1;while(j>=0&&rows[indices[j]].median()<rows[v].median()){indices[j+1]=indices[j];--j;}indices[j+1]=v;}
    return n;
  }
};
