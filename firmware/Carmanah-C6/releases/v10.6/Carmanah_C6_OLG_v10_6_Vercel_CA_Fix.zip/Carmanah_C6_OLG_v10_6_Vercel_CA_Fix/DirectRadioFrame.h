#pragma once
#include <stdint.h>
#include <stddef.h>
#include <string.h>

// RF layout copied from Carmanah_Fallback_v3_2.ino::sendOneRadio.
// FCF8861, PAN3332, destination0000, source0001, LE16 application length.
// out[0] is PSDU length, including two hardware-generated FCS bytes.
inline bool buildDirectRadioFrame(const char *message, uint8_t sequence,
                                 uint8_t *out, size_t cap) {
  const size_t n = strlen(message);
  const size_t psdu = 9 + 2 + n + 2;
  if (!n || n > 100 || psdu > 127 || cap < psdu + 1) return false;
  memset(out, 0, psdu + 1);
  out[0] = uint8_t(psdu);
  out[1] = 0x61; out[2] = 0x88; out[3] = sequence;
  out[4] = 0x32; out[5] = 0x33;
  out[6] = 0x00; out[7] = 0x00;
  out[8] = 0x01; out[9] = 0x00;
  const uint16_t appLength = uint16_t(n + 2);
  out[10] = uint8_t(appLength); out[11] = uint8_t(appLength >> 8);
  memcpy(out + 12, message, n);
  return true;
}
