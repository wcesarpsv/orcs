#pragma once
#include <Preferences.h>
#include <time.h>
#include "SignInventoryCore.h"

bool inventoryScanRequested=false;
bool inventoryScanOnly=false;
uint32_t inventoryScanAt=0;
String savedRdl;
uint8_t expectedSigns=1;
SignInventoryCore signInventory;
bool inventoryDirty=false;
uint32_t inventoryLastSave=0;
uint32_t inventoryValidFrames=0;
uint32_t identityProbeAttempts=0,identityProbeSent=0,identityProbeFailed=0;

void inventoryClearAssociations() {
  for(uint8_t i=0;i<signInventory.count;++i)signInventory.rows[i].confirmed=false;
  inventoryDirty=true;
}

bool inventorySave() {
  if(!inventoryDirty)return true;
  JsonDocument doc;doc["rdl"]=savedRdl;
  doc["ranking_mature"]=signInventory.observing&&uint32_t(millis()-signInventory.windowStarted)>=60000;
  JsonArray list=doc["signs"].to<JsonArray>();
  for(uint8_t i=0;i<signInventory.count;++i){
    const SignObservation &r=signInventory.rows[i];JsonObject o=list.add<JsonObject>();
    o["sn"]=r.sn;o["first"]=r.firstEpoch;o["last"]=r.lastEpoch;
    o["total"]=r.total;o["confirmed"]=r.confirmed;
    o["window_samples"]=r.windowSamples;
    if(r.sampleCount)o["last_median"]=r.median();
  }
  String raw;serializeJson(doc,raw);
  Preferences p;if(!p.begin("carm-inventory",false))return false;
  size_t written=p.putString("observed",raw);String check=p.getString("observed","");p.end();
  if(!written||check!=raw){Serial.println("Inventory save failed; retained in RAM.");return false;}
  inventoryDirty=false;inventoryLastSave=millis();return true;
}

void inventoryLoad() {
  Preferences p;if(!p.begin("carm-inventory",true))return;
  String raw=p.getString("observed","");p.end();JsonDocument doc;
  if(deserializeJson(doc,raw)||String(doc["rdl"]|"")!=savedRdl)return;
  for(JsonObject o:doc["signs"].as<JsonArray>()){
    const char* sn=o["sn"]|"";
    if(!inventorySnValid(sn)||signInventory.find(sn)>=0||signInventory.count==SignInventoryCore::capacity)continue;
    SignObservation &r=signInventory.rows[signInventory.count++];strcpy(r.sn,sn);
    r.firstEpoch=o["first"]|0U;r.lastEpoch=o["last"]|0U;r.total=o["total"]|0U;
    r.confirmed=o["confirmed"]|false;
    r.windowSamples=o["window_samples"]|0U;
    int median=o["last_median"]|-127;
    if(median>=-126&&median<=0){r.samples[0]=int8_t(median);r.sampleCount=1;r.nextSample=1;}
  }
  if(doc["ranking_mature"]|false){
    signInventory.observing=true;signInventory.windowStarted=millis()-60000U;
  }
}

void inventoryConfigChanged(const String& previousRdl,uint8_t previousCount) {
  if(previousRdl!=savedRdl){signInventory=SignInventoryCore();inventoryDirty=true;}
  else if(previousCount!=expectedSigns)inventoryClearAssociations();
  inventorySave();
}

void inventoryDocument(JsonDocument &doc) {
  uint32_t epoch=uint32_t(time(nullptr));
  doc["schema_version"]=1;doc["rdl"]=savedRdl;doc["expected_signs"]=expectedSigns;
  doc["device_id"]=WiFi.macAddress();
  doc["association_policy"]="median_rssi_suggestion_then_manual_confirmation";
  doc["backend_configured"]=false;doc["uploaded"]=false;
  doc["report_interval_seconds"]=10800;
  doc["identity_probe_mode"]="experimental_IQ_from_observed_log";
  doc["iq_attempts_this_window"]=identityProbeAttempts;
  doc["iq_radio_success_this_window"]=identityProbeSent;
  doc["iq_radio_failed_this_window"]=identityProbeFailed;
  doc["validated_ia_messages"]=inventoryValidFrames;
  doc["capacity"]=unsigned(SignInventoryCore::capacity);doc["table_full_drops"]=signInventory.dropped;
  doc["clock_valid"]=epoch>=1700000000U;
  uint8_t order[SignInventoryCore::capacity];uint8_t ranked=signInventory.ranking(order,millis(),epoch>=1700000000U?epoch:0);
  doc["ranking_ready"]=ranked>=expectedSigns;
  doc["ambiguous_boundary"]=ranked>expectedSigns&&
    signInventory.rows[order[expectedSigns-1]].median()-signInventory.rows[order[expectedSigns]].median()<6;
  JsonArray list=doc["signs"].to<JsonArray>();
  for(uint8_t i=0;i<signInventory.count;++i){
    const SignObservation &r=signInventory.rows[i];JsonObject o=list.add<JsonObject>();
    o["sn"]=r.sn;o["first_seen_unix"]=r.firstEpoch;o["last_seen_unix"]=r.lastEpoch;
    o["received_count"]=r.total;o["samples_this_window"]=r.windowSamples;
    if(r.sampleCount)o["median_rssi_dbm"]=r.median();else o["median_rssi_dbm"]=nullptr;
    o["confirmed"]=r.confirmed;bool suggested=false;
    for(uint8_t j=0;j<ranked&&j<expectedSigns;++j)if(order[j]==i)suggested=true;
    o["suggested"]=suggested;
    bool recent=epoch>=1700000000U&&r.lastEpoch&&r.lastEpoch<=epoch&&epoch-r.lastEpoch<10800;
    o["status"]=!r.confirmed?"unassigned":recent?"active_recently_detected":"no_recent_detection";
  }
}

// Accept a complete, checksum-validated IA only inside a known legacy MAC
// payload. Do not combine pieces from different radios or scan MAC/FCS bytes.
void inventoryReceiveFrame(const uint8_t* data,size_t size,int8_t rssi) {
  if(size<11)return;
  uint16_t fcf=uint16_t(data[0])|(uint16_t(data[1])<<8);
  if((fcf&7)!=1||(fcf&0x0308)||((fcf>>12)&3)>1||
     ((fcf>>10)&3)!=2||((fcf>>14)&3)!=2||!(fcf&0x40)||data[3]!=0x32||data[4]!=0x33)return;
  const size_t end=size-2;
  for(size_t i=9;i+16<=end;++i){
    if(data[i]!=':')continue;
    int hi=inventoryHex(char(data[i+1])),lo=inventoryHex(char(data[i+2]));
    if(hi<0||lo<0)continue;size_t n=size_t(hi*16+lo);
    if(n<16||n>32||i+n>end)continue;
    char sn[25];if(!inventoryParseIA(reinterpret_cast<const char*>(data+i),n,sn,sizeof(sn)))continue;
    ++inventoryValidFrames;
    uint32_t epoch=uint32_t(time(nullptr));if(epoch<1700000000U)epoch=0;
    if(signInventory.add(sn,rssi,epoch)){
      inventoryDirty=true;
      Serial.printf("SN FOUND: %s RSSI=%d RDL=%s (association pending unless confirmed)\n",sn,rssi,savedRdl.c_str());
    }
    i+=n-1;
  }
}
