#include <Arduino.h>
#include "esp_attr.h"
#include <WiFi.h>
#include <HTTPClient.h>
#include <WiFiClientSecure.h>
#include <ArduinoJson.h>
#include "BenchProtocol.h"
#include "DirectRadioFrame.h"
#include "AutoRadioSchedule.h"
#include "IdentityProbeSchedule.h"
#include "SnapshotValidation.h"
#include <Arduino_GFX_Library.h>
#include <Wire.h>
#include "esp_ieee802154.h"

struct DisplayResumeCache { uint32_t magic; int one,two,three; };
RTC_NOINIT_ATTR DisplayResumeCache resumeDisplay;
uint32_t wifiBootReadyAt=0;
// Wi-Fi, API URL and CA are configured through the setup page.
static const char* API_URL = "https://orcs-reports.vercel.app/api/jackpots";
static const uint32_t POLL_MS = 15000UL; // retry failed Wi-Fi/API fetches
static const uint32_t DATA_TTL_MS = 300000UL;
// AUTO: fresh Wi-Fi snapshot -> 5 minutes of radio rounds -> Wi-Fi again.
bool autoEnabled = true;
static const bool DEBUG_SIGN_FRAMES = false;
uint32_t lastApiPoll = 0;
uint32_t lastApiSuccess = 0;
uint32_t serverExpiresAt = 0;
bool apiEverPolled = false;
bool apiValid = false;
bool apiTxPending = false;
int apiOne = 0, apiTwo = 0, apiThree = 0;
uint8_t pendingTxIndex = 0;
uint32_t lastPendingTx = 0;
String lastSignCandidate = "";

#include "VercelTrust.h"
#include "SignInventory.h"
#include "WifiSetup.h"

// ==================================================
// WAVESHARE ESP32-C6 TOUCH LCD 1.83
// ==================================================

#define LCD_SCK  1
#define LCD_DIN  2
#define LCD_DC   3
#define LCD_RST  4
#define LCD_CS   5
#define LCD_BL   6

#define TP_SDA   7
#define TP_SCL   8
#define TP_INT  11

#define SCREEN_WIDTH  240
#define SCREEN_HEIGHT 284

#define COLOR_BLACK   0x0000
#define COLOR_WHITE   0xFFFF
#define COLOR_GREEN   0x07E0
#define COLOR_RED     0xF800
#define COLOR_BLUE    0x001F
#define COLOR_YELLOW  0xFFE0
#define COLOR_CYAN    0x07FF
#define COLOR_GRAY    0x7BEF
#define COLOR_DARK    0x2104

Arduino_DataBus *bus =
  new Arduino_HWSPI(LCD_DC, LCD_CS, LCD_SCK, LCD_DIN);

Arduino_GFX *gfx =
  new Arduino_ST7789(
    bus,
    LCD_RST,
    0,
    true,
    SCREEN_WIDTH,
    SCREEN_HEIGHT
  );

// ==================================================
// RADIO IEEE 802.15.4
// ==================================================

static uint8_t RADIO_CHANNEL = 12;
static const uint16_t CARMANAH_PAN = 0x3332;

struct RadioPacket {
  uint8_t size;
  int8_t rssi;
  uint8_t data[127];
};

void processPacket(const RadioPacket &packet);
void updateScreen(bool force);
void addLogLine(const String &line);

QueueHandle_t packetQueue = nullptr;
volatile bool radioNeedsRearm = false;
volatile bool txBusy = false;
volatile int lastTxError = 0;
volatile int txOutcome = 0; // 1 = radio sent, -1 = radio failed
bool radioReady = false;
bool radioMonitoring = false;
void startDiagnosticRadio(bool monitor);
void requestDirectSend();
void setAutoEnabled(bool enabled);
void requestWifiReturn();
void serviceWifiReturn();
bool radioSession = false;
bool directSendCycle = false;
bool cycleAwaitingResult = false;
AutoRadioSchedule autoSchedule;
IdentityProbeSchedule identitySchedule;
bool identityAwaitingResult=false;
void serviceIdentityProbe();
int cycleOne=0, cycleTwo=0, cycleThree=0;
uint16_t roundsStarted=0;
uint32_t lastCountdownDraw=0;
uint8_t directSentCount = 0;
uint32_t rebootAfterTx = 0;
bool wifiReturnPending = false;
bool refreshingValues = false;
uint32_t failedRadioFrames = 0;
uint8_t txFrame[128] = {}; // static lifetime until TX callback
uint32_t txStarted = 0;
uint8_t txSequence = 1;
bool txFault = false;

String serialCommand;

void IRAM_ATTR esp_ieee802154_transmit_done(
  const uint8_t *frame, const uint8_t *ack,
  esp_ieee802154_frame_info_t *ackInfo
) {
  if (ack) esp_ieee802154_receive_handle_done(ack);
  txOutcome = 1;
  txBusy = false;
  radioNeedsRearm = true;
}

void IRAM_ATTR esp_ieee802154_transmit_failed(
  const uint8_t *frame, esp_ieee802154_tx_error_t error
) {
  lastTxError = int(error);
  txOutcome = -1;
  txBusy = false;
  radioNeedsRearm = true;
}


void IRAM_ATTR esp_ieee802154_receive_done(
  uint8_t *frame,
  esp_ieee802154_frame_info_t *frameInfo
) {
  RadioPacket packet;

  packet.size = frame[0];
  if (packet.size > sizeof(packet.data)) {
    packet.size = sizeof(packet.data);
  }

  packet.rssi = frameInfo ? frameInfo->rssi : -127;
  memcpy(packet.data, &frame[1], packet.size);

  BaseType_t wakeTask = pdFALSE;
  xQueueSendFromISR(packetQueue, &packet, &wakeTask);

  esp_ieee802154_receive_handle_done(frame);

  // esp_ieee802154_receive() termina depois de um frame valido. O rearme
  // sera feito imediatamente no loop(), fora do contexto de interrupcao.
  radioNeedsRearm = true;

  if (wakeTask == pdTRUE) {
    portYIELD_FROM_ISR();
  }
}

// ==================================================
// DADOS E ESTADOS
// ==================================================

String valueOne = "--";
String valueTwo = "--";
String valueThree = "--";

uint32_t lastOneRJ = 0;
uint32_t lastTwoRJ = 0;
uint32_t lastThreeRJ = 0;
uint32_t lastAnyRJ = 0;
uint32_t qjWithoutRJSince = 0;
uint32_t lastCarmanahPacket = 0;

int8_t lastRSSI = -127;

// Parser continuo do protocolo Carmanah. Nao depende de uma mensagem inteira
// estar contida no mesmo callback/frame IEEE 802.15.4.
String carmanahRxBuffer;
bool carmanahCapturing = false;
static const size_t MAX_CARMANAH_MESSAGE = 96;

// 0 = dashboard; 1 = logs
uint8_t currentScreen = 0;
bool logPaused = false;
bool logDirty = false;

#define MAX_LOG_LINES 12
String logBuffer[MAX_LOG_LINES];
uint8_t logHead = 0;

String displayedStatus = "";
String displayedOne = "";
String displayedTwo = "";
String displayedThree = "";
int8_t displayedRSSI = -127;

uint32_t lastScreenCheck = 0;
uint32_t lastLogDraw = 0;
uint32_t lastTouchAction = 0;

// ==================================================
// HELPERS
// ==================================================

bool isRecent(uint32_t timestamp, uint32_t ageMs = 20000) {
  return timestamp > 0 && millis() - timestamp < ageMs;
}

bool hasCompleteRecentRJ() {
  return
    isRecent(lastOneRJ) &&
    isRecent(lastTwoRJ) &&
    isRecent(lastThreeRJ);
}

uint8_t recentRJCount() {
  uint8_t count = 0;
  if (isRecent(lastOneRJ)) count++;
  if (isRecent(lastTwoRJ)) count++;
  if (isRecent(lastThreeRJ)) count++;
  return count;
}

String currentStatus() {
  if (!portalReady&&!radioSession) return "AP ERROR";
  if (inventoryScanOnly) return "SN LISTEN";
  if (directSendCycle) return "RADIO CYCLE";
  if (refreshingValues) return "UPDATING";
  if (savedSsid.isEmpty()) return "WIFI SETUP";
  if (apiValid && lastApiSuccess && millis() - lastApiSuccess < DATA_TTL_MS && time(nullptr) < serverExpiresAt) return "SITE ONLINE";
  if (lastApiSuccess) return "STALE";
  return WiFi.status() == WL_CONNECTED ? "SITE WAIT" : "WIFI OFF";
}

void addLogLine(const String &line) {
  logBuffer[logHead] = line;
  logHead = (logHead + 1) % MAX_LOG_LINES;
  logDirty = true;
}

String extractValue(const String &message) {
  int dollar = message.indexOf('$');
  int semicolon = message.indexOf(';');

  if (dollar < 0 || semicolon <= dollar) {
    return "--";
  }

  return message.substring(dollar + 1, semicolon);
}

bool hasCarmanahPan(const RadioPacket &packet) {
  // Para o formato curto XBee observado:
  // FCF(2), sequence(1), PAN little-endian(2)
  return
    packet.size >= 5 &&
    packet.data[3] == lowByte(CARMANAH_PAN) &&
    packet.data[4] == highByte(CARMANAH_PAN);
}

// ==================================================
// DIRECT TX: frame format from Carmanah_Fallback_v3_2.ino.
// TX callback confirms the local radio result; check the physical sign.
// ==================================================

String buildRJ(const String &id, unsigned value) {
  char message[48];
  if (!benchBuildRJ(id.c_str(), value, message, sizeof(message))) return "";
  return String(message);
}

bool sendBenchRJ(const String &id, unsigned value) {
  if (!radioReady || txBusy || txFault) {
    Serial.println("BLOCKED: radio not ready/busy/fault."); return false;
  }
  String m = buildRJ(id, value);
  if (m.isEmpty() || !buildDirectRadioFrame(m.c_str(), txSequence++, txFrame, sizeof(txFrame))) {
    Serial.println("BLOCKED: invalid command/frame."); return false;
  }
  lastTxError = 0; txOutcome = 0; txStarted = millis(); txBusy = true;
  esp_err_t e = esp_ieee802154_transmit(txFrame, true);
  if (e != ESP_OK) {
    txBusy = false; radioNeedsRearm = true;
    lastTxError=int(e);
    Serial.printf("TX start failed: %d\n", int(e)); return false;
  }
  Serial.print("DIRECT TX queued: "); Serial.println(m);
  addLogLine("TX " + m);
  return true;
}

void serviceIdentityProbe() {
  if(!radioReady||!radioMonitoring||txBusy||txFault||txOutcome||
     cycleAwaitingResult||identityAwaitingResult||wifiReturnPending||rebootAfterTx)return;
  bool slotAvailable=inventoryScanOnly;
  if(directSendCycle&&!autoSchedule.ended(millis())&&pendingTxIndex>=3){
    const uint32_t phase=autoSchedule.elapsed(millis())%AutoRadioSchedule::intervalMs;
    slotAvailable=phase>=3500&&phase<4000;
  }
  if(!identitySchedule.take(millis(),slotAvailable))return;
  identityProbeAttempts=identitySchedule.attempts;
  if(!buildDirectRadioFrame(IdentityProbeSchedule::command(),txSequence++,txFrame,sizeof(txFrame))){
    ++identityProbeFailed;return;
  }
  lastTxError=0;txOutcome=0;txStarted=millis();
  identityAwaitingResult=true;txBusy=true;
  esp_err_t e=esp_ieee802154_transmit(txFrame,true);
  if(e!=ESP_OK){
    txBusy=false;identityAwaitingResult=false;lastTxError=int(e);
    radioNeedsRearm=true;++identityProbeFailed;
    Serial.printf("IQ start failed: %d\n",int(e));addLogLine("IQ START FAILED");return;
  }
  Serial.printf("IQ TEST %u/3: :089aIQ; (waiting for validated IA)\n",identitySchedule.attempts);
  addLogLine("TX IQ :089aIQ;");
}

void requestDirectSend() {
  if (directSendCycle || wifiReturnPending || rebootAfterTx || txBusy || txFault) {
    Serial.println("SEND blocked: active TX/fault."); return;
  }
  if (!apiValid || millis()-lastApiSuccess >= DATA_TTL_MS || time(nullptr) >= serverExpiresAt) {
    Serial.println("SEND blocked: fetch valid Streamlit values first."); return;
  }
  Serial.printf("Preparing direct TX: %d/%d/%d CH=%u PAN=3332. Wi-Fi will stop.\n",
    apiOne, apiTwo, apiThree, RADIO_CHANNEL);
  startDiagnosticRadio(false);
  if (!radioReady) return;
  directSendCycle = true; cycleAwaitingResult = false;
  directSentCount = 0; pendingTxIndex = 3; lastPendingTx = 0;
  cycleOne=apiOne; cycleTwo=apiTwo; cycleThree=apiThree; failedRadioFrames=0;
  autoSchedule.begin(millis()); roundsStarted=0;
  Serial.println("AUTO RADIO: 300 seconds; all 3 values every 5 seconds.");
  apiTxPending = true; currentScreen = 0; updateScreen(true);
}

void setAutoEnabled(bool enabled) {
  autoEnabled = enabled;
  Preferences prefs;
  if (prefs.begin("carmanah-net", false)) {
    if (prefs.putBool("auto-tx", enabled) != 1) Serial.println("AUTO setting not saved; active this boot only.");
    prefs.end();
  } else Serial.println("AUTO setting not saved; active this boot only.");
  Serial.println(enabled ? "AUTO ON" : "AUTO OFF");
  if (!enabled && radioSession) {
    // Allow an in-flight frame to finish; schedule a reboot into Wi-Fi only.
    requestWifiReturn();
  }
  updateScreen(true);
}

void benchHelp() {
  Serial.println("\nC6 OLG v10.6 VERCEL CA FIX - Wi-Fi fetch -> radio 5min -> Wi-Fi fetch");
  Serial.println("Each 5 seconds: send all 3 values. Defaults to AUTO ON.");
  Serial.println("AUTO ON | AUTO OFF (saved) | STATUS | HELP");
  Serial.println("SEND OLG = start a 5min window from valid cached values.");
  Serial.println("RADIO ON = monitor (AUTO OFF first); RADIO OFF = return to Wi-Fi.");
  Serial.println("INVENTORY = SNs plus IQ/IA counters. IQ test: max 3 per radio window, 20s apart.");
}

void readBenchSerial() {
  while (Serial.available()) {
    char c = Serial.read();
    if (c == '\r') continue;
    if (c != '\n') {
      if (serialCommand.length() < 100) serialCommand += c;
      else serialCommand = "";
      continue;
    }
    String cmd = serialCommand; serialCommand = ""; cmd.trim();
    if (cmd == "INVENTORY") {
      JsonDocument doc;inventoryDocument(doc);serializeJsonPretty(doc,Serial);Serial.println();
    } else if (cmd == "AUTO ON") {
      setAutoEnabled(true);
    } else if (cmd == "AUTO OFF") {
      setAutoEnabled(false);
    } else if (cmd == "RADIO ON") {
      if (autoEnabled) Serial.println("Use AUTO OFF before manual radio monitoring.");
      else startDiagnosticRadio(true);
    } else if (cmd == "RADIO OFF") {
      if (txBusy || txFault) {
        Serial.println("TX active/fault: automatic reboot pending, or power-cycle.");
      } else {
        Serial.println("Restarting with RADIO OFF. Wi-Fi settings remain saved.");
        inventorySave();Serial.flush(); ESP.restart();
      }
    } else if (cmd == "HELP") benchHelp();
    else if (cmd == "SEND OLG") {
      requestDirectSend();
    }
    else if (cmd == "STATUS") {
      Serial.printf("AUTO=%d RADIO=%s CH=%u busy=%d fault=%d ROUND=%u SENT=%u/3 LEFT=%lus API=%d\n",
                    autoEnabled, radioReady ? "ON" : "OFF", RADIO_CHANNEL, txBusy, txFault, roundsStarted, directSentCount,
                    (unsigned long)(directSendCycle ? autoSchedule.secondsLeft(millis()) : 0), apiValid);
    } else {
      char extra; int channel;
      if (sscanf(cmd.c_str(), "CH %d %c", &channel, &extra) == 1 &&
          channel >= 11 && channel <= 26 && !directSendCycle && !txBusy && !txFault) {
        RADIO_CHANNEL = channel;
        if (radioReady) esp_ieee802154_set_channel(RADIO_CHANNEL);
        Serial.printf("Channel=%u (not saved after reboot).\n", RADIO_CHANNEL);
      } else Serial.println("Unknown/blocked command. Type HELP.");
    }
  }
}

// ==================================================
// PROCESSAMENTO CARMANAH
// ==================================================

void processMessage(const String &message, int8_t packetRSSI) {
  uint32_t now = millis();

  lastRSSI = packetRSSI;
  lastCarmanahPacket = now;

  bool isQJ =
    message.indexOf("QJone") >= 0 ||
    message.indexOf("QJtwo") >= 0 ||
    message.indexOf("QJthree") >= 0;

  if (isQJ && qjWithoutRJSince == 0) {
    qjWithoutRJSince = now;
  }

  if (message.indexOf("RJone$") >= 0) {
    // RJ received: diagnostic only; screen values come from API.
    lastOneRJ = now;
    lastAnyRJ = now;
  }

  if (message.indexOf("RJtwo$") >= 0) {
    // RJ received: diagnostic only; screen values come from API.
    lastTwoRJ = now;
    lastAnyRJ = now;
  }

  if (message.indexOf("RJthree$") >= 0) {
    // RJ received: diagnostic only; screen values come from API.
    lastThreeRJ = now;
    lastAnyRJ = now;
  }

  if (hasCompleteRecentRJ()) {
    qjWithoutRJSince = 0;
  }

  String logLine =
    "[" + String(packetRSSI) + "dBm] " + message;

  addLogLine(logLine);

  Serial.printf(
    "Carmanah: %s | RSSI: %d dBm\n",
    message.c_str(),
    packetRSSI
  );
}

void processPacket(const RadioPacket &packet) {
  if (packet.size == 0 || !hasCarmanahPan(packet)) return;
  inventoryReceiveFrame(packet.data,packet.size,packet.rssi);
  // Direct TX does not learn or depend on captured packets.
  if (DEBUG_SIGN_FRAMES) {
    // Show complete raw radio frames and MAC addressing for sign-serial discovery.
    // Do not treat MAC as the sign's printed serial number without validation.
    Serial.printf("RX PAN3332 RSSI=%d len=%u RAW=", packet.rssi, packet.size);
    for (int j=0; j<packet.size; ++j) Serial.printf("%02X", packet.data[j]);
    Serial.println();
    uint16_t fcf = packet.size >= 2 ? (uint16_t(packet.data[0]) | (uint16_t(packet.data[1])<<8)) : 0;
    Serial.printf("MAC FCF=%04X dst_mode=%u src_mode=%u\n", fcf, (fcf>>10)&3, (fcf>>14)&3);
  }

  // Varre TODOS os bytes. Um unico pacote pode conter one/two/three, e uma
  // mensagem incompleta permanece no buffer para ser concluida no proximo.
  for (uint8_t i = 0; i < packet.size; i++) {
    uint8_t byteValue = packet.data[i];

    // ':' sempre inicia uma nova mensagem Carmanah. Se uma captura anterior
    // estava incompleta/corrompida, ela e descartada aqui.
    if (byteValue == ':') {
      carmanahRxBuffer = ":";
      carmanahCapturing = true;
      continue;
    }

    if (!carmanahCapturing) continue;

    // Bytes binarios do cabecalho/FCS nao pertencem ao texto Carmanah.
    // Ignora-os, mas mantem uma eventual mensagem fragmentada em andamento.
    if (byteValue < 0x20 || byteValue > 0x7E) continue;

    carmanahRxBuffer += static_cast<char>(byteValue);

    if (byteValue == ';') {
      processMessage(carmanahRxBuffer, packet.rssi);
      carmanahRxBuffer = "";
      carmanahCapturing = false;
      continue;
    }

    // Protecao contra lixo de radio ou mensagem sem terminador.
    if (carmanahRxBuffer.length() >= MAX_CARMANAH_MESSAGE) {
      carmanahRxBuffer = "";
      carmanahCapturing = false;
    }
  }
}

// ==================================================
// DASHBOARD
// ==================================================

void printCentered(
  const String &text,
  int y,
  int size,
  uint16_t color
) {
  int width = text.length() * 6 * size;
  int x = (SCREEN_WIDTH - width) / 2;
  if (x < 0) x = 0;

  gfx->setTextSize(size);
  gfx->setTextColor(color);
  gfx->setCursor(x, y);
  gfx->print(text);
}

void drawValueBox(
  int x,
  const String &label,
  const String &value
) {
  gfx->drawRoundRect(x, 138, 68, 72, 8, COLOR_WHITE);

  gfx->setTextSize(1);
  gfx->setTextColor(COLOR_CYAN);
  gfx->setCursor(x + 31, 146);
  gfx->print(label);

  int valueWidth = value.length() * 18;
  int valueX = x + (68 - valueWidth) / 2;
  if (valueX < x + 2) valueX = x + 2;

  gfx->setTextSize(3);
  gfx->setTextColor(COLOR_WHITE);
  gfx->setCursor(valueX, 170);
  gfx->print(value);
}

void drawDashboard(bool force = false) {
  String status = currentStatus();

  bool majorChange =
    status != displayedStatus ||
    valueOne != displayedOne ||
    valueTwo != displayedTwo ||
    valueThree != displayedThree;

  bool meaningfulRSSIChange =
    abs(static_cast<int>(lastRSSI) - static_cast<int>(displayedRSSI)) >= 3;

  if (!force && !majorChange && !meaningfulRSSIChange) {
    return;
  }

  displayedStatus = status;
  displayedOne = valueOne;
  displayedTwo = valueTwo;
  displayedThree = valueThree;
  displayedRSSI = lastRSSI;

  uint16_t background = COLOR_DARK;
  uint16_t statusColor = COLOR_YELLOW;

  if (status == "SITE ONLINE" || status == "RADIO CYCLE" || status == "UPDATING") {
    background = 0x0320;
    statusColor = COLOR_GREEN;
  } else if (status == "DOTS") {
    background = 0x4000;
    statusColor = COLOR_RED;
  } else if (status == "PARTIAL") {
    background = 0x4200;
    statusColor = COLOR_YELLOW;
  }

  gfx->fillScreen(background);

  printCentered("CARMANAH OLG C6", 18, 2, COLOR_WHITE);
  printCentered(directSendCycle ? (String("AUTO RF ") + String(autoSchedule.secondsLeft(millis())) + "s") : (radioReady ? "RADIO ON / WIFI OFF" : "WIFI ON / RADIO OFF"), 53, 1, COLOR_YELLOW);
  gfx->drawFastHLine(16, 46, 208, COLOR_CYAN);

  int statusSize = status.length() > 10 ? 2 : 3;
  printCentered(status, 72, statusSize, statusColor);

  if (status == "SN LISTEN") {
    printCentered(String("SN: ")+String(signInventory.count)+" / RDL "+savedRdl,112,1,COLOR_WHITE);
  } else if (status == "UPDATING") {
    printCentered("LAST VALUES / REFRESHING", 112, 1, COLOR_WHITE);
  } else if (status == "RADIO CYCLE") {
    printCentered(failedRadioFrames ? (String("RF ERR ") + String(lastTxError) + " / RETRY NEXT ROUND") : (String("SN: ") + String(signInventory.count) + " / RDL " + savedRdl), 112, 1, COLOR_WHITE);
  } else if (status == "SITE ONLINE") {
    printCentered("FROM YOUR STREAMLIT", 112, 1, COLOR_WHITE);
  } else if (status == "DOTS") {
    printCentered("SERVER DATA STALE", 112, 1, COLOR_WHITE);
  } else if (status == "PARTIAL") {
    printCentered(
      String(recentRJCount()) + "/3 RJ VALUES",
      112,
      1,
      COLOR_WHITE
    );
  } else {
    printCentered("CH 12 / PAN 3332", 112, 1, COLOR_WHITE);
  }

  drawValueBox(8, "1", valueOne);
  drawValueBox(86, "2", valueTwo);
  drawValueBox(164, "3", valueThree);

  gfx->drawFastHLine(16, 226, 208, COLOR_CYAN);

  gfx->setTextSize(2);
  gfx->setTextColor(COLOR_WHITE);
  gfx->setCursor(18, 242);
  gfx->print("RSSI: ");

  if (lastRSSI == -127) {
    gfx->print("--");
  } else {
    gfx->print(lastRSSI);
    gfx->print(" dBm");
  }

  gfx->setTextSize(1);
  gfx->setTextColor(COLOR_GRAY);
  gfx->fillRoundRect(8, 260, 108, 24, 4, COLOR_BLUE);
  gfx->fillRoundRect(124, 260, 108, 24, 4, COLOR_BLUE);
  gfx->setTextColor(COLOR_WHITE);
  gfx->setCursor(20, 268); gfx->print("Wi-Fi setup");
  gfx->setCursor(136, 268); gfx->print(autoEnabled ? "AUTO ON" : "AUTO OFF");
}

// ==================================================
// PAGINA DE LOGS
// ==================================================

void drawPauseButton() {
  uint16_t background = logPaused ? COLOR_RED : COLOR_YELLOW;
  uint16_t textColor = logPaused ? COLOR_WHITE : COLOR_BLACK;

  gfx->fillRoundRect(150, 4, 82, 24, 4, background);
  gfx->setTextSize(1);
  gfx->setTextColor(textColor);
  gfx->setCursor(165, 12);
  gfx->print(logPaused ? "RESUME" : "PAUSE");
}

void drawLogScreen(bool force = false) {
  if (force) {
    gfx->fillScreen(COLOR_BLACK);

    gfx->setTextSize(2);
    gfx->setTextColor(COLOR_CYAN);
    gfx->setCursor(8, 8);
    gfx->print("RADIO LOGS");

    drawPauseButton();
    gfx->drawFastHLine(8, 32, 224, COLOR_CYAN);

    gfx->setTextSize(1);
    gfx->setTextColor(COLOR_GRAY);
    gfx->setCursor(8, 268);
    gfx->print("Swipe right to return");
  }

  if (logPaused && !force) {
    return;
  }

  gfx->fillRect(0, 38, SCREEN_WIDTH, 225, COLOR_BLACK);
  gfx->setTextSize(1);
  gfx->setTextColor(COLOR_WHITE);

  int y = 42;

  for (int i = 0; i < MAX_LOG_LINES; i++) {
    int index = (logHead + i) % MAX_LOG_LINES;

    if (logBuffer[index].length() > 0) {
      gfx->setCursor(8, y);
      gfx->print(logBuffer[index].substring(0, 36));
      y += 18;
    }
  }

  logDirty = false;
  lastLogDraw = millis();
}

void drawWifiSetupScreen() {
  gfx->fillScreen(COLOR_DARK);
  printCentered("WI-FI SETUP", 18, 2, COLOR_CYAN);
  printCentered("Connect phone/laptop to:", 60, 1, COLOR_WHITE);
  printCentered("Carmanah-Setup", 85, 2, COLOR_WHITE);
  printCentered("Password: carmanah123", 118, 1, COLOR_YELLOW);
  printCentered("Open browser:", 150, 1, COLOR_WHITE);
  printCentered("192.168.4.1", 173, 2, COLOR_CYAN);
  printCentered("Save your Wi-Fi on the page", 212, 1, COLOR_WHITE);
  printCentered("Tap below to return", 236, 1, COLOR_GRAY);
  gfx->fillRoundRect(8, 260, 224, 24, 4, COLOR_BLUE);
  printCentered("BACK", 266, 1, COLOR_WHITE);
}

void updateScreen(bool force = false) {
  if (currentScreen == 2) {
    if (force) drawWifiSetupScreen();
    return;
  }
  if (currentScreen == 0) {
    drawDashboard(force);
  } else if (
    force ||
    (!logPaused && logDirty && millis() - lastLogDraw >= 250)
  ) {
    drawLogScreen(force);
  }
}

// ==================================================
// TOUCH CST816D
// ==================================================

void initTouch() {
  Wire.begin(TP_SDA, TP_SCL);
  Wire.setClock(400000);
  pinMode(TP_INT, INPUT_PULLUP);
  delay(100);
}

void readTouch() {
  Wire.beginTransmission(0x15);
  Wire.write(0x01);

  if (Wire.endTransmission() != 0) {
    return;
  }

  Wire.requestFrom(0x15, 6);
  if (Wire.available() < 6) {
    return;
  }

  uint8_t gesture = Wire.read();
  uint8_t points = Wire.read();
  uint8_t xHigh = Wire.read() & 0x0F;
  uint8_t xLow = Wire.read();
  uint8_t yHigh = Wire.read() & 0x0F;
  uint8_t yLow = Wire.read();

  int16_t x = (xHigh << 8) | xLow;
  int16_t y = (yHigh << 8) | yLow;

  if (millis() - lastTouchAction < 350) {
    return;
  }

  if (points > 0 && currentScreen == 0 && y >= 260 && x >= 124 && x < SCREEN_WIDTH) {
    lastTouchAction = millis(); setAutoEnabled(!autoEnabled); return;
  }
  if (points > 0 && y >= 260 && x >= 0 && x < SCREEN_WIDTH) {
    if (currentScreen == 0 || currentScreen == 2) {
      currentScreen = currentScreen == 0 ? 2 : 0;
      lastTouchAction = millis(); updateScreen(true); return;
    }
  }
  if (gesture == 0x04 && currentScreen == 2) {
    currentScreen = 0; lastTouchAction = millis(); updateScreen(true); return;
  }

  // 0x03 = swipe left; 0x04 = swipe right
  if (gesture == 0x03 && currentScreen == 0) {
    currentScreen = 1;
    lastTouchAction = millis();
    updateScreen(true);
    return;
  }

  if (gesture == 0x04 && currentScreen == 1) {
    currentScreen = 0;
    lastTouchAction = millis();
    updateScreen(true);
    return;
  }

  // Botao PAUSE/RESUME na pagina de logs
  if (
    currentScreen == 1 &&
    points > 0 &&
    x >= 145 && x <= 239 &&
    y >= 0 && y <= 38
  ) {
    logPaused = !logPaused;
    lastTouchAction = millis();
    drawPauseButton();

    if (!logPaused) {
      drawLogScreen(false);
    }
  }
}

// ==================================================
// HTTP API: source of displayed numbers (not transceiver)
// ==================================================
void pollJackpots() {
  refreshingValues=false;
  if (WiFi.status() != WL_CONNECTED || wifiApplyPending || savedApiUrl.isEmpty() || savedCa.isEmpty()) {
    apiValid = false; return;
  }
  if (time(nullptr) < 1700000000) { apiValid = false; return; }
  const char* apiHost = "orcs-reports.vercel.app";
  Serial.printf("API_DIAG URL=%s epoch=%lu CA_len=%u heap=%u\n", savedApiUrl.c_str(), (unsigned long)time(nullptr), (unsigned)savedCa.length(), (unsigned)ESP.getFreeHeap());
  IPAddress resolved;
  bool dnsOK = WiFi.hostByName(apiHost, resolved);
  Serial.printf("API_DIAG DNS=%s IP=%s\n", dnsOK ? "OK" : "FAIL", resolved.toString().c_str());
  if (!dnsOK) { apiValid=false; return; }
  WiFiClient tcpProbe;
  tcpProbe.setTimeout(5);
  bool tcpOK = tcpProbe.connect(apiHost, 443, 5000);
  Serial.printf("API_DIAG TCP443=%s\n", tcpOK ? "OK" : "FAIL");
  tcpProbe.stop();
  if (!tcpOK) { apiValid=false; return; }
  WiFiClientSecure tls;
  tls.setCACert(savedCa.c_str()); // public CA trust bundle; TLS verification remains enabled
  tls.setTimeout(12000);
  HTTPClient http;
  http.useHTTP10(true);
  String requestUrl = savedApiUrl;
  if (!http.begin(tls, requestUrl)) { Serial.println("API_DIAG HTTP begin failed"); apiValid=false; return; }
  http.setFollowRedirects(HTTPC_STRICT_FOLLOW_REDIRECTS);
  http.setTimeout(12000);
  http.addHeader("Cache-Control", "no-cache");
  http.addHeader("Accept", "application/json");
  apiTxPending = false;
  int code = http.GET();
  if (code != 200) {
    Serial.printf("API HTTP %d (%s)\n", code, http.errorToString(code).c_str());
    if (code > 0) {
      String response = http.getString();
      Serial.printf("API_DIAG response: %.300s\n", response.c_str());
      Serial.printf("API_DIAG location: %s\n", http.getLocation().c_str());
    } else {
      Serial.println("API_DIAG No HTTP response. DNS/TCP success implies TLS/handshake or connection interruption.");
    }
    apiValid=false; http.end(); return;
  }
  if (http.getSize() > 8192) { apiValid=false; http.end(); Serial.println("Snapshot too large"); return; }
  JsonDocument doc;
  DeserializationError error = deserializeJson(doc, http.getStream());
  http.end();
  if (error || strcmp(doc["status"] | "", "ok") != 0 || !(doc["transmit_allowed"] | false)) {
    apiValid=false; Serial.println("API invalid/not approved"); return;
  }
  const uint32_t nowEpoch = uint32_t(time(nullptr));
  if ((doc["schema_version"] | 0) != 1 ||
      !doc["generated_at_unix"].is<uint32_t>() || !doc["expires_at_unix"].is<uint32_t>()) {
    apiValid=false; Serial.println("Snapshot schema/timestamps missing"); return;
  }
  uint32_t generated = doc["generated_at_unix"].as<uint32_t>();
  uint32_t expires = doc["expires_at_unix"].as<uint32_t>();
  if (!validSnapshotTimes(generated, expires, nowEpoch)) {
    apiValid=false; Serial.println("Vercel snapshot expired or clock invalid"); return;
  }
  JsonVariant a=doc["values"]["lotto_max"], b=doc["values"]["gold_ball"], c=doc["values"]["maxmillions"];
  if (!a.is<int>() || !b.is<int>() || !c.is<int>()) { apiValid=false; return; }
  int x=a.as<int>(), y=b.as<int>(), z=c.as<int>();
  if (x<1 || x>200 || y<1 || y>200 || z<0 || z>200) { apiValid=false; return; }
  bool changed = !lastApiSuccess || x!=apiOne || y!=apiTwo || z!=apiThree;
  apiOne=x; apiTwo=y; apiThree=z;
  resumeDisplay.one=x;resumeDisplay.two=y;resumeDisplay.three=z;resumeDisplay.magic=0xC6100201U;
  valueOne=String(x); valueTwo=String(y); valueThree=String(z);
  apiValid=true; refreshingValues=false; lastApiSuccess=millis(); serverExpiresAt=expires;
  Serial.printf("Vercel OLG: %d / %d / %d (changed=%d)\n",x,y,z,changed);
  addLogLine("API " + valueOne + "/" + valueTwo + "/" + valueThree);

  updateScreen(true);
}

void processApiTx() {
  if (!directSendCycle || wifiReturnPending || rebootAfterTx) return;
  // Snapshot freshness is required to enter a window. The three accepted
  // values are held for exactly this user-requested five-minute window.
  // No new window can start without another successful HTTPS validation.
  if (autoSchedule.ended(millis())) {
    if (!txBusy && !cycleAwaitingResult) {
      requestWifiReturn();
      Serial.println("300s completed. Returning to Wi-Fi without reboot; display retained.");
    }
    return;
  }
  if (cycleAwaitingResult || !radioReady || txBusy || txFault) return;
  if (pendingTxIndex >= 3) {
    if (!autoSchedule.takeRound(millis())) return;
    pendingTxIndex=0; directSentCount=0; lastPendingTx=0; ++roundsStarted;
    Serial.printf("RADIO round %u: %d/%d/%d; %lus left\n", roundsStarted,
      cycleOne,cycleTwo,cycleThree,(unsigned long)autoSchedule.secondsLeft(millis()));
  }
  if (lastPendingTx && millis()-lastPendingTx < 1500) return;
  const char* ids[]={"one","two","three"};
  const unsigned values[]={unsigned(cycleOne),unsigned(cycleTwo),unsigned(cycleThree)};
  if (sendBenchRJ(String(ids[pendingTxIndex]),values[pendingTxIndex])) {
    cycleAwaitingResult=true;
  } else {
    ++failedRadioFrames; ++pendingTxIndex;
    Serial.println("TX start failed. Continue remaining values; retry next 5-second round.");
  }
  lastPendingTx=millis();
}

void requestWifiReturn() {
  directSendCycle=false; apiTxPending=false; wifiReturnPending=true;
}

void serviceWifiReturn() {
  if(!wifiReturnPending||txBusy||cycleAwaitingResult||identityAwaitingResult||txFault)return;
  // RX+TX returned an unreliable Wi-Fi restart on this hardware. Use the
  // already proven Wi-Fi-only boot path instead of trusting the mode label.
  esp_err_t error=radioReady?esp_ieee802154_disable():ESP_OK;
  radioReady=false;radioMonitoring=false;radioNeedsRearm=false;
  if(error!=ESP_OK)Serial.printf("Radio stop error=%d; restart recovery.\n",int(error));
  // Drain completed RX packets before persisting, so the final IA is included.
  RadioPacket received;
  while(packetQueue&&xQueueReceive(packetQueue,&received,0)==pdTRUE)processPacket(received);
  bool saved=inventorySave();
  if(!saved){
    // Keep the in-memory observations accessible in the Serial log before
    // recovery; never claim they were saved if NVS failed.
    JsonDocument data;inventoryDocument(data);serializeJson(data,Serial);Serial.println();
    Serial.println("Inventory save FAILED. Copy INVENTORY from Serial before reset.");
    addLogLine("SN SAVE FAILED / SERIAL");
    wifiReturnPending=false;return;
  }
  wifiReturnPending=false;
  Serial.println("SN inventory saved. Restarting into Wi-Fi-only boot in 1 second.");
  currentScreen=0;refreshingValues=true;updateScreen(true);
  rebootAfterTx=millis();
}

void startDiagnosticRadio(bool monitor) {
  if (radioReady) { Serial.println("Radio already ON."); return; }
  if (packetQueue == nullptr) { Serial.println("RADIO blocked: packet queue not available."); return; }
  // End Wi-Fi fully before enabling the shared 2.4GHz radio.
  radioSession = true;
  WiFi.softAPdisconnect(true);
  WiFi.disconnect(false, false); // keep credentials
  WiFi.mode(WIFI_OFF);
  delay(250);
  esp_err_t result = esp_ieee802154_enable();

  if (result != ESP_OK) {
    gfx->fillScreen(COLOR_RED);
    printCentered("RADIO ERROR", 120, 2, COLOR_WHITE);
    Serial.printf("Radio enable failed: %d. Returning to Wi-Fi.\n", int(result));
    rebootAfterTx=millis();
    return;
  }

  // RX only while Wi-Fi is OFF; interleave receive with existing TX slots.
  radioMonitoring = true;
  esp_ieee802154_set_promiscuous(true);
  esp_ieee802154_set_rx_when_idle(true);
  signInventory.beginWindow(millis());
  identitySchedule.begin(millis());
  identityProbeAttempts=identityProbeSent=identityProbeFailed=0;
  esp_ieee802154_set_channel(RADIO_CHANNEL);
  esp_ieee802154_set_panid(CARMANAH_PAN);
  esp_ieee802154_set_short_address(0x0001);

  result = esp_ieee802154_receive();

  if (result != ESP_OK) {
    gfx->fillScreen(COLOR_RED);
    printCentered("RX ERROR", 120, 2, COLOR_WHITE);
    esp_err_t cleanup = esp_ieee802154_disable();
    rebootAfterTx=millis();
    Serial.printf("Radio RX failed: %d; disable result: %d. Power-cycle before repeating.\n", int(result), int(cleanup));
    return;
  }

  Serial.println("Carmanah C6 Monitor started.");
  Serial.println("Channel 12 / PAN 0x3332");

  radioReady = true;
  Serial.println("RADIO ON / Wi-Fi OFF. Five-minute transmission window.");
  Serial.println("At 300 seconds the C6 returns to Wi-Fi for fresh values.");
  updateScreen(true);
}

// ==================================================
// SETUP
// ==================================================

void setup() {
  Serial.begin(115200);
  delay(1000);
  initWifiSetup();
  Preferences autoPrefs;
  if (autoPrefs.begin("carmanah-net", true)) {
    autoEnabled=autoPrefs.getBool("auto-tx", true); autoPrefs.end();
  }

  if (!gfx->begin()) {
    Serial.println("Display initialization failed.");
  }

  pinMode(LCD_BL, OUTPUT);
  digitalWrite(LCD_BL, HIGH);

  initTouch();

  gfx->fillScreen(COLOR_BLACK);
  printCentered("STARTING...", 120, 2, COLOR_CYAN);

  packetQueue = xQueueCreate(30, sizeof(RadioPacket));

  if (packetQueue == nullptr) {
    gfx->fillScreen(COLOR_RED);
    printCentered("QUEUE ERROR", 120, 2, COLOR_WHITE);
    return;
  }

  if(esp_reset_reason()==ESP_RST_SW&&resumeDisplay.magic==0xC6100201U&&
     resumeDisplay.one>=1&&resumeDisplay.one<=200&&resumeDisplay.two>=1&&resumeDisplay.two<=200&&resumeDisplay.three>=0&&resumeDisplay.three<=200){
    valueOne=String(resumeDisplay.one);valueTwo=String(resumeDisplay.two);valueThree=String(resumeDisplay.three);
    refreshingValues=true; // display only; apiValid remains false
  }
  wifiBootReadyAt=millis();
  Serial.println("C6 OLG v10.6 VERCEL CA FIX: Wi-Fi first; next valid snapshot starts radio cycle.");
  benchHelp();
  updateScreen(true);
}

// ==================================================
// LOOP
// ==================================================

void loop() {
  if (!radioSession) {
    serviceWifiSetup();
    if(inventoryDirty&&millis()-inventoryLastSave>=300000)inventorySave();
  }
  readBenchSerial();
  readTouch();
  if(inventoryScanRequested&&!radioSession&&millis()-inventoryScanAt>=750){
    inventoryScanRequested=false;setAutoEnabled(false);startDiagnosticRadio(true);
    if(radioReady){inventoryScanOnly=true;inventoryScanAt=millis();}
  }
  if(inventoryScanOnly&&millis()-inventoryScanAt>=60000&&!txBusy)requestWifiReturn();
  static uint32_t diagLastCheck = 0;
  static int diagLastWifi = -999;
  static int diagLastClients = -999;
  if (millis() - diagLastCheck >= 1000) {
    diagLastCheck = millis();
    int wifiStatus = int(WiFi.status());
    int clients = int(WiFi.softAPgetStationNum());
    if (wifiStatus != diagLastWifi || clients != diagLastClients) {
      diagLastWifi = wifiStatus; diagLastClients = clients;
      Serial.printf("DIAG radio=%s AP_clients=%d STA_status=%d AP_IP=%s\n",
        radioReady ? "ON" : "OFF", clients, wifiStatus, WiFi.softAPIP().toString().c_str());
    }
  }
  // Keep setup responsive while a phone/laptop is connected to the portal.
  // HTTPS requests in v5 are synchronous; defer them until setup is finished.
  if (!radioSession && !wifiApplyPending && WiFi.softAPgetStationNum() == 0 &&
      WiFi.status() == WL_CONNECTED && !savedApiUrl.isEmpty() &&
      !savedCa.isEmpty() && time(nullptr) >= 1700000000 && !txBusy &&
      (!apiEverPolled || millis()-lastApiPoll >= POLL_MS)) {
    apiEverPolled=true; lastApiPoll=millis(); pollJackpots();
  }
  if (!directSendCycle && apiValid && (millis()-lastApiSuccess >= DATA_TTL_MS || time(nullptr) >= serverExpiresAt)) { apiValid=false; apiTxPending=false; }
  if (autoEnabled && millis()-wifiBootReadyAt>=15000 && !radioSession && !wifiApplyPending &&
      WiFi.softAPgetStationNum()==0 && apiValid && !wifiReturnPending && !rebootAfterTx) requestDirectSend();
  serviceWifiReturn();
  if (txOutcome) {
    int result = txOutcome; txOutcome = 0;
    if (result == 1) Serial.println("TX SENT (verify physical sign)");
    else Serial.printf("TX FAILED: driver error=%d\n", int(lastTxError));
    bool belongedToCycle=cycleAwaitingResult;
    cycleAwaitingResult=false;
    if(identityAwaitingResult){
      identityAwaitingResult=false;
      if(result==1){++identityProbeSent;addLogLine("IQ radio sent / listen IA");}
      else {++identityProbeFailed;addLogLine("IQ radio callback failed");}
    } else if (directSendCycle && belongedToCycle) {
      if (result == 1) {
        ++directSentCount; ++pendingTxIndex;
        Serial.printf("DIRECT sent %u/3\n", directSentCount);
        updateScreen(false);
        if (directSentCount == 3) {
          Serial.println("Round complete: 3/3. Waiting for next 5-second slot.");
        }
      } else {
        ++failedRadioFrames; ++pendingTxIndex;
        Serial.println("RF callback failed; buffer released. Continue round, retry next slot.");
      }
    }
  }
  processApiTx();
  serviceIdentityProbe();
  if (txBusy && millis() - txStarted > 3000 && !txFault) {
    txFault = true;
    rebootAfterTx=millis();
    Serial.println("TX callback timeout. Returning to Wi-Fi by reboot.");
  }

  // Rearma o receptor depois de CADA frame. Sem isto o C6 recebe RJone e
  // volta para IDLE antes de RJtwo/RJthree, que chegam poucos ms depois.
  if (radioReady && radioMonitoring && radioNeedsRearm && !txBusy && !txFault) {
    radioNeedsRearm = false;

    if (
      esp_ieee802154_get_state() !=
      ESP_IEEE802154_RADIO_RECEIVE
    ) {
      esp_err_t rxResult = esp_ieee802154_receive();

      if (rxResult != ESP_OK) {
        // Se o driver ainda estiver mudando de estado, tenta novamente no
        // proximo ciclo em vez de abandonar a recepcao.
        radioNeedsRearm = true;
      }
    }
  }

  RadioPacket packet;

  while (
    packetQueue != nullptr && xQueueReceive(packetQueue, &packet, 0) == pdTRUE
  ) {
    processPacket(packet);
  }

  if (directSendCycle && currentScreen==0 && millis()-lastCountdownDraw >= 1000) {
    lastCountdownDraw=millis();
    // Only redraw the countdown strip, never erase the three number boxes.
    gfx->fillRect(0, 50, SCREEN_WIDTH, 12, 0x0320);
    printCentered(String("AUTO RF ") + String(autoSchedule.secondsLeft(millis())) + "s", 53, 1, COLOR_YELLOW);
    gfx->fillRect(0, 110, SCREEN_WIDTH, 12, 0x0320);
    printCentered(failedRadioFrames ? (String("RF ERR ") + String(lastTxError) + " / RETRY NEXT ROUND") : (String("SN: ") + String(signInventory.count) + " / RDL " + savedRdl),112,1,COLOR_WHITE);
  }
  if (millis() - lastScreenCheck >= 250) {
    lastScreenCheck = millis();
    updateScreen();
  }

  if (rebootAfterTx && millis()-rebootAfterTx >= 1200 && (!txBusy || txFault)) {
    // A reboot returns to the proven Wi-Fi-only boot path, including after
    // driver faults. Never overwrite a static frame awaiting its callback.
    if (radioReady && !txBusy) {
      esp_ieee802154_disable();
      radioReady = false;
    }
    Serial.println("Rebooting to Wi-Fi. Saved settings preserved.");
    Serial.flush(); ESP.restart();
  }
  delay(10);
}
